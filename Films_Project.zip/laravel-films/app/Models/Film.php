<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Film extends Model
{
protected $fillable = [
    'title',
    'genre',
    'year',
    'watched',
    'description',
    'actors',
    'image',
];

}
