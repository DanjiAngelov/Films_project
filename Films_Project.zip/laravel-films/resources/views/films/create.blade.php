<textarea name="description"
    placeholder="Description"
    class="w-full border rounded px-3 py-2"></textarea>

<input type="text"
    name="actors"
    placeholder="Actors (comma separated)"
    class="w-full border rounded px-3 py-2">

<input type="url"
    name="image"
    placeholder="Image URL"
    class="w-full border rounded px-3 py-2">
